#include <stdio.h>

int any(char s[], char t[]) {
	int i, j, k;

	for (i = 0; s[i] != '\0'; i++){
		for (j = i, k = 0; t[k] != '\0'; j++){
			if(s[i] == t[k]){
				return i;
			} else {
				k++;
			}
		}
	}
	return -1;
}
int main() {
	char u1[10] = "Hanyang";
	char u2[10] = "Ansan";
	char u3[10] = "ERICA";
	printf("%d\n", any(u1,u2));
	printf("%d\n", any(u2,u3));
	printf("%d\n", any(u3,u1));
	printf("%d\n", any(u2,u1));
	printf("%d\n", any(u3,u2));
	printf("%d\n", any(u1,u3));
}