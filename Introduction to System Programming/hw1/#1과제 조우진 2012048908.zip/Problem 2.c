#include <stdio.h>
void print_bin(unsigned x) {
	const int SIZE = sizeof(x) * 8;
	printf("decimal : %u\n", x);
	printf("binary : ");
	for (int i = 0; i < SIZE; i++)
		printf("%c", (x>>(SIZE-i-1)&1) + 48);
	printf("\n");
}


void print_oct(unsigned x) {
	const int SIZE = sizeof(x) * 8;
	printf("decimal : %u\n", x);
	printf("octal : ");
	for (int i = 0; i < SIZE; i++)
		printf("%c", (x>>(SIZE-i-1)&7) + 48);
	printf("\n");
}


void print_hex(unsigned x) {
	const int SIZE = sizeof(x) * 8;
	printf("decimal : %u\n", x);
	printf("hexadecimal : ");
	for (int i = 0; i < SIZE; i++){
		if(x % 16 < 10){
			printf("%c", (x>>(SIZE-i-1)&10) + 48);
		} else {
			printf("%c", (x>>(SIZE-i-1)&5) + 65);
		}
	}
	printf("\n");
}

int main() {
	unsigned x = 25;
	print_bin(x);
	print_oct(x);
	print_hex(x);
	return 0;
}